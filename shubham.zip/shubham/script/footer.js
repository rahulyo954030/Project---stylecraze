const footer = () => {
    return `    <div id="footer">
    <div>
        <a href="https://www.stylecraze.com/about-us/">About Us</a>
        <a href="https://www.stylecraze.com/image-usage-policy/">Image Usage Policy</a>
        <a href="https://www.stylecraze.com/contact-us/"> Contact us</a>
        <a href="https://www.stylecraze.com/editorial-guidelines/">Editorial Guideliness</a>
        <a href="https://www.stylecraze.com/doctors-join/">Join Our Medical Board</a>
        <a href="https://www.stylecraze.com/doctors-join/">Press Room</a>

    </div>
    <div>
        <a href="https://www.stylecraze.com/advertise-with-us/">Advertise With Us</a>
        <a href="https://www.stylecraze.com/privacy-policy/">Privacy Policy</a>
        <a href="https://www.stylecraze.com/terms-of-use/">Term Of Use</a>
        <a href="https://www.stylecraze.com/affiliate-disclosure/">Affiliate Discloure</a>
        <a href="https://www.stylecraze.com/cookie-policy/">Cookie Policy</a>
        <a href="https://www.stylecraze.com/manage-subscriptions/?ref=footer">Manage Sbscription</a>
    </div>
    <div>
        <div>
            <h3>Follow Us</h3>
        </div>

        <div>
        <a href="https://www.facebook.com/StyleCraze/" target="_blank"> <img
                src="https://img.freepik.com/free-icon/facebook-logo-with-rounded-corners_318-9850.jpg?w=2000" />
        </a>
        <a href="https://in.pinterest.com/stylecraze/"   target="_blank">
           <img src="https://png.pngtree.com/element_our/md/20180626/md_5b321fcda2483.jpg" />

        </a>
        <a href="https://twitter.com/stylecrazeindia/" target="_blank">
            <img
                src="https://cdn-icons-png.flaticon.com/512/81/81609.png" />

        </a>
        <a href="https://www.instagram.com/accounts/login/?next=/style.craze/" target="_blank">
            <img
                src="https://toppng.com/uploads/preview/new-black-instagram-logo-2020-11609370162ayxbdxlffo.png" />

        </a>

        <a href="https://www.youtube.com/user/StylecrazeTV" target="_blank">

            <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1zmKt_j4VUbGiSpQ7kQ658lLxIyaYL-4TpwxzV69t6zkXbDpXpEKhp4MPW0xi0Wl_2As&usqp=CAU" />
        </a>
    </div>

    </div>
    <div>
        <h3>Our Sister Sites</h3>
        <a href="https://www.momjunction.com/">Mom Junction</a>
        <a href="https://www.thebridalbox.com/">The Bridal Box</a>
        <a href="https://skinkraft.com/">SkinCraft</a>
        <a href="https://vedix.com/">Vedix</a>

    </div>
</div>
<div id="footer_child">
    <div id="footer_bottom_first">
        <P>
            Copyright © 2011 - 2022 <a href="https://www.incnut.com/">Incnut Digital.</a> All rights reserved.
        </P>
    </div>
    <div id="footer_bottom_second">
        StyleCraze provides content of general nature that is designed for informational purposes only. The content
        is not intended to be a substitute for professional medical advice, diagnosis, or treatment. <a
            href="https://www.stylecraze.com/disclaimer/">
            Click here for
        </a>
    </div>
</div>
`
}
export default footer